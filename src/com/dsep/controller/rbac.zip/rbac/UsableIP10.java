package com.dsep.controller.rbac;

import java.util.ArrayList;

public class UsableIP10 {
	public String username;
	public String password;
	public String location;
	public ArrayList<String> ips = new ArrayList<String> ();
	public Boolean isValidate;
	public Integer avaliableWinNum;
	public Integer port;
	public String info;
	public Long remainTime;
}
