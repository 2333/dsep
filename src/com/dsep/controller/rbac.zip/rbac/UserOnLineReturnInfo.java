package com.dsep.controller.rbac;

public class UserOnLineReturnInfo {
	private boolean ret;

	private String info;
	
	public boolean isRet() {
		return ret;
	}

	public void setRet(boolean ret) {
		this.ret = ret;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	
}
