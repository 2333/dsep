package com.dsep.controller.rbac;

public class ReturnInfo {
	private Boolean isValidate;
	private Integer avaliableWinNum;
	public Boolean getIsValidate() {
		return isValidate;
	}
	public void setIsValidate(Boolean isValidate) {
		this.isValidate = isValidate;
	}
	public Integer getAvaliableWinNum() {
		return avaliableWinNum;
	}
	public void setAvaliableWinNum(Integer avaliableWinNum) {
		this.avaliableWinNum = avaliableWinNum;
	} 
}
